
%%Not for clinical use - ONLY FOR INVESTIGATIONAL PURPOSES
%%Sample  steps for creating tvalue map from fMRI-DBS data
%
%%Input parameters: 
%%fmrifile:fmri filename (nifti file format), example fmridbs.nii
%%PID:Patient ID
%%tr:Scan Repetition time (in seconds)
%
%%Can also be manually entered using the
%%model_job_template_spm.mat file in the SPM batch GUI

function spm_batch_DBSmodel(fmrifile, PID, tr)

SPMPath='spm12';
addpath(genpath(SPMPath));

[o1,SeriesID] = fileparts(fmrifile);
dataPath = fileparts(fileparts(o1));
partID={['Data_' num2str(PID) '/' num2str(SeriesID) '_SPMpreprocessed']};
prefix=[SeriesID '_']; 

iPart=1;

%Find processed files
fn = dir([o1 '/swa*']);
for iVol=1:length(fn)
    func_files{iVol}=fullfile(dataPath,partID{iPart},fn(iVol).name);
end;

func_files{1}=func_files';
func_files(2:end)=[];

%% Slice time correction
load('model_job_template_spm.mat'); % Load template 

%%Specify model directory
if ~exist([o1 '/model'], 'dir')
    mkdir([o1 '/model'])
end
matlabbatch{1}.spm.stats.fmri_spec.dir{1} = [o1 '/model'];

%%Specify TR 
matlabbatch{1}.spm.stats.fmri_spec.timing.RT = tr;

%%Specify preprocessed file for model
matlabbatch{1}.spm.stats.fmri_spec.sess.scans = func_files{1};

%Specify motion regressor file
MotionFile=dir([o1 '/rp*.txt']);%%Motion regressor from art-toolbox or SPM preprocessing
MotionFn = [o1 '/' MotionFile(1).name];

matlabbatch{1}.spm.stats.fmri_spec.sess.multi_reg{1} = MotionFn;

%Save model and run
save(fullfile(dataPath,partID{iPart},'model','spm_model_job.mat'),'matlabbatch');
spm_jobman('run',matlabbatch);