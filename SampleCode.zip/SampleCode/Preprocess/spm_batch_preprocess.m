
%% Boutet, Madhavan et al, 2021
%%Not for clinical use 
%%Sample preprocessing steps for fMRI-DBS data
%%Sample preprocessing can also be manually entered using the
%%preprocess_job_template_spm.mat file in the SPM batch GUI
%
%%Input parameters: 
%%fmrifile:fmri  filename (nifti file format), example fmridbs.nii
%%T1file: structural T1 filename (nifti file format), example t1.nii
%%PID:Patient ID
%%%%%%
%%%NOTE:
%%%%%
%%Before starting, open the preprocess_job_template_spm.mat in SPM Batch GUI and
%%in the section Segment --> Tissue --> choose Tissue probability maps from
%%spm12/tmp/TPM.nii for 6 tissue probability templates. Save the batch
%%preprocess template before running this code.


function spm_batch_preprocess(fmrifile,T1file,PID)

SPMPath='spm12'; %%%Change this to your path
addpath(genpath(SPMPath));

%Split 4D to 3D volumes
spm_file_split(fmrifile) %%Split 4D fMRI to 3D volumes

[o1,SeriesID] = fileparts(fmrifile);
dataPath = fileparts(fileparts(o1));
partID={['Data_' num2str(PID) '/' num2str(SeriesID) '_SPMpreprocessed']};
prefix=[SeriesID '_']; 
nVol=180;%%%%Specify number of volumes to be included
dummies=10; % Specify Dummy volumes to be discarded in the start of fMRI preprocessing depending on your protocol

iPart=1;

for iVol=1:nVol
    func_files{iVol}=fullfile(dataPath,partID{iPart},[prefix,num2str(iVol+dummies,'%05d'),'.nii']);
end

func_files{1}=func_files';
func_files(2:end)=[];

anat_file = T1file;

% %% Open a sample image and try to get tr
vs=spm_vol(func_files{1}{1});
if(~exist('tr','var'))
    tr=vs.private.timing.tspace;
    if(tr>10) %units are probably in msec
        tr=tr/1000;
    elseif(tr<0.5)
        tr=tr.*1000;
    end
    warning(['Verify TR is ',num2str(tr),' seconds']);
end


%% Slice time correction
load('preprocess_job_template_spm.mat'); % Load template 
ir=1;

matlabbatch{1}.spm.temporal.st.scans{ir} = func_files{ir};

matlabbatch{1}.spm.temporal.st.nslices=vs.dim(3); %Assumes that the 3rd dimension is slices
matlabbatch{1}.spm.temporal.st.tr=tr;
matlabbatch{1}.spm.temporal.st.ta= tr - (tr/vs.dim(3));

matlabbatch{1}.spm.temporal.st.so = [1:2:matlabbatch{1}.spm.temporal.st.nslices, ...
    2:2:matlabbatch{1}.spm.temporal.st.nslices];

matlabbatch{1}.spm.temporal.st.refslice = round(matlabbatch{1}.spm.temporal.st.nslices/2);
prefix=['a'];

%% Realignment
n=1;
ir=1;
%for ir=1:length(func_files) % Each session
    for i=1:length(func_files{ir}), %Each dynamic
        [func_dir,func_file,ext]=fileparts(func_files{ir}{i});
        matlabbatch{2}.spm.spatial.realign.estimate.data{ir}{n} = ...
            fullfile(func_dir,[prefix,func_file,ext]);
        n=n+1;
%    end;
end;
matlabbatch{2}.spm.spatial.realign.estimate.data{ir} = ...
    matlabbatch{2}.spm.spatial.realign.estimate.data{ir}';

%% Coregistration
[func_dir,func_file,ext]=fileparts(func_files{1}{1});
matlabbatch{3}.spm.spatial.coreg.estimate.ref{1}=fullfile(func_dir,[prefix,func_file,ext]);
matlabbatch{3}.spm.spatial.coreg.estimate.source{1}=anat_file;
matlabbatch{3}.spm.spatial.coreg.estimate.other{1}='';

%% Segmentation

matlabbatch{4}.spm.spatial.preproc.channel.vols{1}=anat_file;


%% Spatial normalization

[anat_dir,anat_file_nodir,ext]=fileparts(anat_file);
matlabbatch{5}.spm.spatial.normalise.write.subj.def={};
matlabbatch{5}.spm.spatial.normalise.write.subj.def{1} = ...
    fullfile(anat_dir,['y_',anat_file_nodir,ext]);

matlabbatch{5}.spm.spatial.normalise.write.subj.resample={'t';'t'};
n=1;
iR=1;
%for iR=1:length(func_files)
    for iV=1:length(func_files{iR})
        [func_dir,func_file,ext]=fileparts(func_files{iR}{iV});
        matlabbatch{5}.spm.spatial.normalise.write.subj.resample{n} = ...
            fullfile(func_dir,[prefix,func_file,ext]);
        n=n+1;
    end;
%end;
prefix=['wa'];




%% Smooth the data 
n=1;
iR=1;

for iV=1:length(func_files{iR})
    [func_dir,func_file,ext]=fileparts(func_files{iR}{iV});
    matlabbatch{6}.spm.spatial.smooth.data{n} = ...
        fullfile(func_dir,[prefix,func_file,ext]);
    n=n+1;
end


%%
save(fullfile(dataPath,partID{iPart},'spm_preprocess_job.mat'),'matlabbatch');
spm_jobman('run',matlabbatch);