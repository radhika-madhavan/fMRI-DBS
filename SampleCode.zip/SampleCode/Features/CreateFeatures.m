%%Radhika Madhavan
%%Feburary 2020
%%Code to generate normalized features from 16 region of interest derived
%%from SPM processed fMRI t-value maps as described in Methods, Boutet,
%%Madhavan et al 2021
%%
%Example code to generate features for four ROIs and example data included
%in repository. This can be repeated across patients and multiple series.
%%Not to be used for clinical purposes
%%If used please reference: Boutet, Madhavan, Nature Comm, 2021

dataDir='fMRI-DBS-master/data';
MaskDir='fMRI-DBS-master/Masks';

%%%%ROIs
Seednames={'L_thalamus.nii','L_sensorimotor.nii','PrimaryVisual.nii','SecondaryVisual.nii'};

%%%All settings

MeanActivation={};MeanActivation_pos={};MeanActivation_neg={};
for seed=1:length(Seednames)

    mask=load_nii([MaskDir '/' Seednames{seed}]);
    mask=double(mask.img);

    %%%Mean activation in ROI
    data=[];
    data=load_nii([dataDir '/model/spmT_0001.nii']);
    data=double(data.img);
    D=[];D=immultiply(data,mask);
    if ~isempty(find(D<0))
        MeanActivation_neg(numsettings,seed)=prctile((D(D<0)),10); %%DBS-ON<DBS-OFF
    else
        MeanActivation_ne(numsettings,seed)=-.01;
    end
    if ~isempty(find(D>0))
        MeanActivation_pos(numsettings,seed)=prctile((D(D>0)),90);%DNS-ON>DBS-OFF
    else
        MeanActivation_pos(numsettings,seed)=.01;
    end

end


%Normalize by Visual
DataNorm1=[];DataNorm2=[];
for settings=1:size(Alln,1)
    Data1=[];Data1=MeanActivation_neg(settings,:);
    Data2=[];Data2=MeanActivation_pos(settings,:);

    DataNorm1=Data1./sum(Data2([3:4]));%Normalize by activation in visual areas
    DataNorm2=Data2./sum(Data2([3:4]));%Normalize by activation in visual areas

end

